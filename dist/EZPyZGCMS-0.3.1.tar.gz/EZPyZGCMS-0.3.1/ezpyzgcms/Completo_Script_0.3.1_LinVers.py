from pyms.GCMS.IO.ANDI import ANDI_reader
from pyms.Noise.SavitzkyGolay import savitzky_golay
from pyms.IntensityMatrix import build_intensity_matrix_i
from pyms.TopHat import tophat
import pandas as pd
from Completo_Functions import completoCM, completoData
import openpyxl as xl
from openpyxl.utils.dataframe import dataframe_to_rows
from os import path
from glob import glob
import matplotlib.pyplot as plt
import time


def find_ext(dr, ext):
    return glob(path.join(dr,"*.{}".format(ext)))
######################
#Graphing Functions
def grabber(df, ref, MetaboliteName): ##grabs certain metabolites(x) off of a reference
    q = df.iloc[df.index.get_loc(df.loc[MetaboliteName].name):\
                df.index.get_loc(df.loc[MetaboliteName].name)+ref[MetaboliteName]]
    return q

###########################################################################
################Script use is below.
listofCDFs = find_ext('.', 'CDF')

class Item:
            """
            This class is the primary information holder for our analysis. It takes parameters from our library (i.e. RT, formula, Ions, and Name) and then
            systematically parses the CDF for abundance information for the


            Valuable outputs:
                RT: Retention time
                self.CorrF:
            """
            __slots__ = ('Name', 'Derivatization', 'RT', 'RTis',
                         'Ions','IonL','ics','RTIndex',
                         'RTadj', 'icsval', 'IntensityDF',
                         'IntensityDFF','FinalRT','RawAbun',
                         'chemicalFormula','mainC','labeledspecies',
                         'CorrRaw','enrichment','CorrF','CorrFixed',
                         'enrichmentFixed','TotalIonCount','enrichmentF',
                         'enrichmentNormalized', 'enrichmentNormalizedNoLab')
            def __init__(self, Name, RT, Ions, chemicalFormula, mainC, labeledspecies):
                self.Name = Name
                self.Derivatization = 'TBDMS'
                self.RT = RT
                self.RTis = RT*60 #Retention time in seconds
                self.Ions = Ions #Ions that you're interested in
                self.IonL = list(range(Ions[0],Ions[1]+1))
                for i in self.IonL:
                    ic = im.get_ic_at_mass(i)
                    ic1 = savitzky_golay(ic)
                    ic_smooth = savitzky_golay(ic1)
                    ic_base = tophat(ic_smooth, struct="1.5m")
                    im.set_ic_at_index(im.get_index_of_mass(i), ic_base)


                self.ics = {x:im.get_ic_at_mass(x) for x in range(self.Ions[0], self.Ions[1]+1)}
                self.RTIndex = self.ics[self.Ions[0]].get_index_at_time(self.RTis)
                self.RTadj = [self.ics[self.Ions[0]].get_index_at_time(self.RTis-15),self.ics[self.Ions[0]].get_index_at_time(self.RTis+15)]
                self.icsval = {x:im.get_ic_at_mass(x).intensity_array for x in range(self.Ions[0], self.Ions[1]+1)}
                self.IntensityDF = pd.DataFrame(self.icsval)
                self.IntensityDF['RT'] =[x/60 for x in im.get_ic_at_mass(self.Ions[0]).time_list]
                #self.IntensityDF['RT (minutes)'] = [x/60 for x in TBDMS_im.get_ic_at_mass(Ions[0]).time_list]
                self.IntensityDFF = self.IntensityDF[self.RTadj[0]:self.RTadj[1]].nlargest(1, list(range(self.Ions[0],self.Ions[1]+1)))
                self.FinalRT = self.IntensityDFF[['RT']].values[0][0]
                self.RawAbun = self.IntensityDFF.values[0][:-1]
                self.chemicalFormula = chemicalFormula
                self.mainC = mainC
                self.labeledspecies = labeledspecies
                self.CorrRaw, self.enrichment = completoData(completoCM(self, labeledspecies), self.RawAbun)
                self.enrichmentFixed = []
                self.TotalIonCount = {self.Name:sum(self.RawAbun)}
                self.CorrFixed = []
                for x in self.enrichment:
                    if x<0:
                        x=0
                        self.enrichmentFixed.append(x)
                    else:
                        self.enrichmentFixed.append(x)
                for x in self.CorrRaw:
                    if x<0:
                        x=0
                        self.CorrFixed.append(x)
                    else:
                        self.CorrFixed.append(x)
                #CorrF is the total Ion abundance for the metabolite in question
                self.CorrF = dict([(self.Name[0:-3]+str(x)+' (M'+str(y)+')', self.CorrFixed[y]) for y,x in enumerate(self.IonL)])
                self.enrichmentF = dict([(self.Name[0:-3]+str(x)+' (M'+str(y)+')', self.enrichmentFixed[y]) for y,x in enumerate(self.IonL)])
                #self.enrichmentNormalized is the fragment information of the metabolite corrected so that they add up to 1.
                self.enrichmentNormalized = dict([(self.Name[0:-3]+str(x)+' (M'+str(y)+')', self.enrichmentFixed[y]/sum(self.enrichmentFixed)) for y,x in enumerate(self.IonL)])
                #same as above but without (Mi) labels (this is to be used with the heatmap)
                self.enrichmentNormalizedNoLab = self.enrichmentFixed/sum(self.enrichmentFixed)

def tempProcessor(listofCDFs):

    def multiFile4JS(GCMS):
        data = GCMS
        global im
        im = build_intensity_matrix_i(data)
        scan, mz = im.size


#-----> Declare Metabolites here:
    # TMS Library (updated on 8/21/20)
        # Loading Control
        """
        Nor218 = Item('Nor_218', 6.00, [218,218], 'C8H20N1O2Si2', '', [])
        Nor246 = Item('Nor_246', Nor218.RT, [246,246], 'C10H24N1O2Si2', '', [])

        #Amino Acids
        VAL218 = Item('VAL_218', 5.51, [218,220], 'C8H20N1O2Si2', '', [''])#3C loss
        LEU232 = Item('LEU_232', 6.51, [232,234], 'C9H22N1O2Si2', '', [''])#3C loss
        ILE232 = Item('ILE_232', 7.00, [232,234], 'C9H22N1O2Si2', '', [''])#3C loss
        PRO259 = Item('PRO_259', 7.77, [259,261], 'C11H25N1O2Si2', '', [''])#Parental
        PRO244 = Item('PRO_244', PRO259.RT, [244,246], 'C10H22N1O2Si2', '', [''])#1methyl loss
        GLY276 = Item('GLY_276', 7.24, [276,278], 'C10H26N1O2Si3', '', [''])#1methyl loss
        SER306 = Item('SER_306', 8.50, [306,308], 'C11H28N1O3Si3', '', [''])#1methyl loss
        THR320 = Item('THR_320', 8.97, [320,322], 'C12H30N1O3Si3', '', [''])#1methyl loss;peak contamination
        MET293 = Item('MET_293', 14.62, [293,295], 'C11H27N1O2S1Si2', '', [''])#Parental
        ASP334 = Item('ASP_334', 13.71, [334,336], 'C12H28N1O4Si3', 'N1', ['N'])#1methyl loss
        CYS322 = Item('CYS_322', 14.88, [322,324], 'C11H28N1O2S1Si3', '', [''])#1methyl loss
        PHE294 = Item('PHE_294', 18.07, [294,296], 'C14H24N1O2Si2', '', [''])#1methyl loss
        GLU348 = Item('GLU_348', 16.82, [348,350], 'C13H30N1O4Si3', 'N1', ['N'])
        ASN348 = Item('ASN_348', 19.55, [348,350], 'C13H32N2O3Si3', 'N1', ['N'])#Parental
        GLN362 = Item('GLN_362', 22.75, [362,364], 'C14H34N2O3Si3', 'N1', ['N'])
        GLN347 = Item('GLN_347', GLN362.RT, [347,349], 'C13H31N2O3Si3', 'N1', ['N'])
        # LYS362 = Item('LYS_362', 25.36, [362,368], 'C15H38N2O2Si3', 'C6', ['C'])#Perhaps, not correct
        LYS434 = Item('LYS_434', 23.82, [434,436], 'C18H46N2O2Si4', '', [''])#Parental
        TYR310 = Item('TYR_310', 27.26, [310,312], 'C14H24N1O3Si2', '', [''])#1methyl loss
        # TRP405 = Item('TRP_405', 35.44, [405,407], 'C19H33N2O2Si3', '', [''])#1methyl loss; can't find the right RT

        # GLN362 = Item('GLN_362', 23.28, [362,363], 'C14H34N2O3Si3', 'N1', [])
        # GLU348 = Item('GLU_348', 18.76, [348,349], 'C13H30N1O4Si3', 'N1', [])
        # ASP334 = Item('ASP_334', 15.75, [334,335], 'C12H28N1O4Si3', 'N1', [])

        # #Pyrimidine
        #DHO374 = Item('DHO_374', 24.4, [374,375], 'C14H30N2O4Si3', 'N1', ['N'])
        #ORO254 = Item('ORO_254', 21.83, [254,255], 'C10H18N2O2Si2', 'N1', ['N'])#Contamination observed
        #ORO357 = Item('ORO_357', ORO254.RT, [357,358], 'C13H23N2O4Si3', 'N1', ['N'])
        #UMP352 = Item('UMP_352', 48.55, [352,353], 'C15H24N2O4Si2', 'N1', ['N']) ##Signal is messy
        #CYTS240 = Item('CYTS_240', 17.00, [240,241], 'C9H18N3OSi2', 'N1', ['N'])#Cytosine
        #URAC241 = Item('URAC_241', 10.24, [241,242], 'C9H17N2O2Si2', 'N1', ['N'])#Uracil
        #THYM270 = Item('THYM_270', 11.02, [270,271], 'C11H22N2O2Si2', 'N1', ['N'])#Thymine
        #URID517 = Item('URID_517', 41.1, [517,518], 'C20H41N2O6Si4', 'N1', ['N'])#Uridine;Uncertain RT

        ##Purine
        #ADE279 = Item('ADE_279', 27.68, [279,281], 'C11H21N5Si2', 'N2', [])#Adenine;N2 from alphaNQ;N2 from amNQ
        # #GUA367 = Item('GUA_367', 33.00, [367,368], 'C14H29N5O1Si3', 'N1', [])#Guanine;N1 from alphaNQ;N3 from amNQ
        # #GNS628 = Item('GNS_628', ????, [628,629], 'C24H50N5O5Si5', 'N1', [])#Guanosine;N1 from alphaNQ;N3 from amNQ
        #ADNS540 = Item('ADNS_540', 44.75, [540,542], 'C21H42N5O4Si4', 'N2', ['N'])#Adenosine;N2 from alphaNQ;N2 from amNQ
        #AMP466 = Item('AMP_466', 50.16, [466,468], 'C19H36N5O3Si3', 'N2', ['N'])

        #TCA
        FUM245 = Item('FUM_245', 9.15, [245,247], 'C9H17O4Si2', '', [''])
        MAL335 = Item('MAL_335', 12.79, [335,337], 'C12H27O5Si3', '', [''])
        AKG304 = Item('AKG_304', 17.82, [304,306], 'C11H22N1O5Si2', '', [''])
        CIT465 = Item('CIT_465', 22.41, [465,467], 'C17H37O7Si4', '', [''])
        @SUC247 = Item('SUC_247', 8.87, [247,249], 'C9H19O4Si2', '', [''])#peak contamination


        #Glycolysis
        GLC319 = Item('GLC_319', 22.31, [319,323], 'C13H31O3Si3', 'C4', ['C'])#C3456
        GLC205 = Item('GLC_205', 22.31, [205,207], 'C8H40N1O4Si4', 'C2', ['C'])#C56
        GLC160 = Item('GLC_160', 22.31, [160,162], 'C6H14N1O2Si', 'C2', ['C'])#C12
        GLC554 = Item('GLC_554', 22.31, [554,560], 'C21H52N1O6Si5', 'C6', ['C'])#parental
        G6P357 = Item('G6P_357', 34.82, [357,359], 'C14H33N1O4Si3', 'C2', ['C'])#C56
        G6P471 = Item('G6P_471', 34.82, [471,475], 'C9H20N1O3Si2', 'C4', ['C'])#C3456
        G6P217 = Item('G6P_217', 34.82, [217,220], 'C9H21O2Si2', 'C3', ['C'])#456
        G6P160 = Item('G6P_160', 34.82, [160,162], 'C6H14N1O2Si', 'C3', ['C'])#12
        # F6P459 = Item('F6P_459', 38.30, [459,462], 'C15H40O6P1Si4', 'C3', ['C'])#C456
        # F6P387 = Item('F6P_387', 38.30, [387,390], 'C12H32O6P1Si3', 'C3', ['C'])#C456
        # F6P357 = Item('F6P_357', 38.30, [357,360], 'C11H30O5P1Si3', 'C2', ['C'])#C56
        GAP400 = Item('GAP_400', 20.96, [400,403], 'C12H31N1O6P1Si3', 'C3', ['C'])
        GAP384 = Item('GAP_384', 20.96, [384,387], 'C11H27N1O6P1Si3', 'C3', ['C'])
        GAP328 = Item('GAP_328', 20.96, [328,331], 'C10H27N1O5P1Si2', 'C3', ['C'])
        DHAP400 = Item('DHAP_400', 22.33, [400,403], 'C12H31N1O6P1Si3', 'C3', ['C'])
        PG3459 = Item('PG3_459', 23.33, [459,462], 'C14H36O7P1Si4', 'C3', ['C'])




        #Glycerol
        G3P445 = Item('G3P_445', 21.23, [445,448], 'C14H38O6P1Si4', 'C3', ['C'])





        #ETC
        # UREA189 = Item('UREA_189', 7.7, [189,191], 'C6H17N2O1Si2', 'N2', ['N'])
        # OXPRO258 = Item('OXPRO_258', 15.6, [258,263], 'C10H20N1O3Si2', 'C5', ['C'])
        # HOXPRO332 = Item('HOXPRO_332', 15.85, [332,337], 'C13H30N1O3Si3', 'C5', ['C'])
        # PUT361 = Item('PUT_361', 22.01, [361,366], 'C15H41N2Si4', 'C5', ['C'])
        # PUT174 = Item('PUT_174', 22.01, [174,175], 'C7H20N1Si2', 'N1', ['N'])
        # FRC364 = Item('FRC_365', 26.7, [364,368], 'C14H34N1O4Si3', 'C4', ['C'])#1234
        # FRC307 = Item('FRC_307', 26.7, [307,310], 'C12H31O3Si3', 'C3', ['C'])#C345
        # MYOINO507 = Item('MYOINO_507', 32.44, [507,513], 'C20H47O5Si5', 'C6', ['C'])
        # R5P604 = Item('R5P_604', 33.29, [604,609], 'C20H51N1O8P1Si5', 'C5', ['C'])
        # R5P459 = Item('R5P_459', 33.29, [459,462], 'C15H40O6P1Si4', 'C3', ['C'])#C345
        # R5P357 = Item('R5P_357', 33.29, [357,359], 'C11H30O5P1Si3', 'C2', ['C'])#45
        # R5P160 = Item('R5P_160', 33.29, [160,162], 'C6H14N1O2Si', 'C2', ['C'])#12
        # SCR451 = Item('SCR_451', 45.85, [451,457], 'C17H39O6Si4', 'C6', ['C'])#glucose
        # SCR437 = Item('SCR_437', 45.85, [437,443], 'C17H41O5Si4', 'C6', ['C'])#fructose

        """

    #TBDMS Library (updated on 8/21/20)
        #Loading Control
        Nor260 = Item('Nor_260', 19.52, [260,260], 'C12H30O1N1Si2', '', [])
        Nor288 = Item('Nor_288', Nor260.RT, [288,288], 'C13H30O2N1Si2', '', [])

        # #Drug
        # #DCA185 = Item('DCA_185', 7.15, [185,188], 'C4H7Cl2O2Si1', 'C3', [])

        # # #Glycolysis
        # GAP1484 = Item('GAP1_484', 37.62, [484,487], 'C18H43O6N1Si3P', 'C3', ['C'])#Verification required
        # GAP2484 = Item('GAP2_484', 38.17, [484,487], 'C18H43O6N1Si3P', 'C3', ['C'])#Verification required
        # GAP3484 = Item('GAP3_484', 38.68, [484,487], 'C18H43O6N1Si3P', 'C3', ['C'])#Verification required
        # PG3585 = Item('PG3_585', 44.14, [585,588], 'C23H54O7Si4P1', 'C3', ['C'])
        # PEP453 = Item('PEP_453', 34.90, [453,456], 'C17H38O6Si3P1', 'C3', ['C'])#Verification required; PEP
        PYR174 = Item('PYR_174', 7.952, [174,177], 'C6H12O3N1Si1', 'C3', ['C'])
        LAC261 = Item('LAC_261', 14.30, [261,264], 'C10H25O2Si2', 'C3', ['C'])

        # # #Glycerol Biosynthesis
        # G3P571 = Item('G3P_571', 42.12, [571,574], 'C23H56O6Si4P1', 'C3', ['C'])
        # G3P2571 = Item('G3P2_571', 43.10, [571,574], 'C23H56O6Si4P1', 'C3', ['C'])

        # #Amino Acids
        # ALA260 = Item('ALA_260', 15.63, [260,263], 'C11H26O2N1Si2', 'C3', ['C'])

        GLY246 = Item('GLY_246', 13.97, [246,248], 'C10H24O2N1Si2', 'C2', ['C'])
        VAL288 = Item('VAL_288', 16.37, [288,293], 'C13H30O2N1Si2', 'C5', ['C'])
        LEU344 = Item('LEU_344', 17.36, [344,350], 'C17H38N1O2Si2', 'C6', ['C'])
        ILE344 = Item('ILE_344', 18.46, [344,350], 'C17H38N1O2Si2', 'C6', ['C'])
        SER432 = Item('SER_432', 25.37, [432,435], 'C20H46N1O3Si3', 'C3', ['C'])
        MET320 = Item('MET_320', 26.98, [320,325], 'C13H30N1O2Si2S1', 'C5', ['C'])
        THR404 = Item('THR_404', 25.94, [404,408], 'C18H42O3N1Si3', 'C4', ['C'])
        # PRO328 = Item('PRO_328', 20.71, [328,332], 'C16H36O2N1Si2', 'C4', ['C'])#Need to confirm the chem formula
        PHE336 = Item('PHE_336', 30.39, [336,345], 'C17H30O2N1Si2', 'C9', ['C'])
        ASP418 = Item('ASP_418', 30.76, [418,422], 'C18H40O4N1Si3', 'C4', ['C'])
        # CYS406 = Item('CYS_406', 34.22, [406,409], 'C17H40N1O2S1Si3', 'C3', ['C'])
        GLU432 = Item('GLU_432', 33.85, [432,437], 'C19H42O4N1Si3', 'C5', ['C'])
        ASN417 = Item('ASN_417', 35.49, [417,421], 'C18H41N2O3Si3', 'C4', ['C'])
        LYS488 = Item('LYS_488', 35.72, [488,494], 'C24H56N2O2Si3', 'C6', ['C'])
        GLN431 = Item('GLN_431', 38.47, [431,436], 'C19H43O3N2Si3', 'C5', ['C'])
        GLN473 = Item('GLN_473', 38.47, [473,478], 'C22H49N2O3Si3', 'C5', ['C'])
        # HIS440 = Item('HIS_440', 43.11, [440,446], 'C20H42N3O2Si3', 'C6', ['C'])
        TYR466 = Item('TYR_466', 42.83, [466,475], 'C23H44N1O3Si3', 'C9', ['C'])

        # # #TCA
        SUC331 = Item('SUC_331', 21.34, [331,336], 'C15H31O4Si2', 'C5', ['C'])
        SUC289 = Item('SUC_289', 21.34, [289,294], 'C12H25O4Si2', 'C5', ['C'])
        FUM287 = Item('FUM_287', 21.8, [287,291], 'C12H23O4Si2', 'C4', ['C'])
        AKG346 = Item('AKG_346', 29.17, [346,351], 'C14H28O5N1Si2', 'C5', ['C'])
        MAL419 = Item('MAL_419', 29.71, [419,423], 'C19H39O5Si3', 'C4', ['C'])

        CIT591 = Item('CIT_591', 42.037, [591,597], 'C26H55O7Si4', 'C6', ['C'])

        """

        #Pyrimidine
        #URAC283 = Item('URAC_283', 22.43, [283,287], 'C12H23N2O2Si2', 'C4', [])

        #PFB-Br Library
        MDA251 = Item('MDA_251', 14.66, [251, 251], 'C10H4O2F5', '', [])
        MDA181 = Item('MDA_181', 14.66, [181, 181], 'C7H2F5', '', [])
        """
#-----> Add them to this list

        Metabolites = [CIT591]
        #                ASN348, TRP405, TYR310, LYS434, DHO374, ORO254, ORO357, UMP352, CYTS240, URID517,
        #                ADE279, ADNS540, AMP466,
        #                FUM245, MAL335, AKG304, CIT465, SUC247]

        #Glc_554_M0, Glc_554_M1, Glc_554_M6,
        #This section pools metabolite information into a singular dictionary.
        results = {q.Name:q.enrichmentNormalized for q in Metabolites}

        resultsnoLab = {q.Name:q.enrichmentNormalizedNoLab for q in Metabolites}
        resultsTotalIonCount = {q.Name:q.TotalIonCount for q in Metabolites}

        IonDict = {q.Name+' (M0)':len(q.IonL) for q in Metabolites}
        CorrRawdict = {q.Name:q.CorrF for q in Metabolites}
        RTdict = {q.Name:q.FinalRT for q in Metabolites}

        return results, resultsnoLab, resultsTotalIonCount, IonDict,\
               CorrRawdict, RTdict, Metabolites

    listofCDFsClean = [x.strip('./CDF') for x in listofCDFs]
    #These are dictionaries that catch the above functions output
    fragDict={}
    fragnolabDict={}

    TICDict={}
    RTdict={}
    IonDict={}
    CorrRawDict = {}



    InterRTDF = pd.DataFrame(columns= listofCDFsClean)
    InterFragDF = pd.DataFrame(columns= listofCDFsClean)
    InterTICDF = pd.DataFrame(columns= listofCDFsClean)
    InterCorrDF = pd.DataFrame(columns= listofCDFsClean)

   #Raw CDF converted into dictionary here for parsing and query
    listofGCMSobs = [ANDI_reader(x) for x in listofCDFs]


    for GCMSobs, CDFFile in zip(listofGCMSobs, listofCDFsClean):
        (fragDict[CDFFile], fragnolabDict[CDFFile], TICDict[CDFFile],
        IonDict[CDFFile], CorrRawDict[CDFFile], RTdict[CDFFile], Metabolites) = multiFile4JS(GCMSobs)


    def dictToDF(dictionary, DF):
        """
        Converts dict to DF
        """
        #print(DF.columns)
        for g in listofCDFsClean:
          for v in dictionary[g].values():
            for e,r in v.items():
                DF.loc[e, g] = r





    """
    listofFragnoLabDFs = {x:pd.DataFrame.from_dict(fragnolabDict[x],
                                                 columns=['M0','M1',
                                                          'M2','M3',
                                                          'M4','M5',
                                                          'M6', 'M7'],
                                                 orient='index')
                                                 for x in fragnolabDict}
    """

    dictToDF(fragDict, InterFragDF)
    dictToDF(TICDict, InterTICDF)
    dictToDF(CorrRawDict, InterCorrDF)

    for g in listofCDFsClean:
          for e,r in RTdict[g].items():
              InterRTDF.loc[e, g] = r
    """
    FragmentDF: a df containing metabolites and their natural isotope abundance corrected fragments
    CorrDF: df of metabolites and their Ion's corrected abundances
    TICDF: a df of total ion abundance of metabolites pre norvaline normalization.
    RTDF: df of metabolites and the RTs at which info was extracted.
    TICDFF: a df of total ion abundance of metabolites post norvaline normalization.
    """
    FragmentDF = pd.DataFrame([InterFragDF[x] for x in listofCDFsClean]).T
    TICDF = pd.DataFrame([InterTICDF[x] for x in listofCDFsClean]).T
    CorrDF = pd.DataFrame([InterCorrDF[x] for x in listofCDFsClean]).T
    RTDF = pd.DataFrame([InterRTDF[x] for x in listofCDFsClean]).T

    ###Norvaline Correction:
#--> Specify which norvaline to normalize to
    #To Hannan: add culture volume correction to below statement
    #TICDFF = TICDF/(TICDF.loc['Nor_260']/TICDF.loc['Nor_260'].mean())

    #TICXFragDF = TICDFF*FragmentDF
    finalFrag= pd.DataFrame()
    """
    This code averages the replicates. If you only have one replicate, please specify '1' replicate

    """
    replis = int(input('How many replicates did you have? '))

    if replis == 1:

        finalFrag = FragmentDF
       # finalFragnolab = listofFragnoLabDFs

    elif replis>1:

        for x in range(0, len(FragmentDF.columns), replis):
            finalFrag[FragmentDF.columns[x][:-1]] = FragmentDF[list(FragmentDF.columns)\
                                                               [x:x+replis]].mean(axis=1)

    return TICDF, FragmentDF, finalFrag, CorrDF, RTDF


wb = xl.Workbook()
ws = wb.active
test=tempProcessor(listofCDFs)

for x in test:
    for r in dataframe_to_rows(x, index=True, header=True):
        ws.append(r)

filename = input('What would you like to save your file as?')
wb.save(filename+'.csv')
